# Signup and Login with PHP and MySQL

Source code to accompany this video: https://youtu.be/5L9UhOnuos0

[![Signup and Login with PHP and MySQL](https://img.youtube.com/vi/5L9UhOnuos0/0.jpg)](https://youtu.be/5L9UhOnuos0)
